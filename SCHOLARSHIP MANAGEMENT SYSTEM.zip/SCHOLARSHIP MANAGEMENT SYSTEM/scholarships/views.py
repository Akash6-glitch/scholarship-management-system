from django.shortcuts import render

# Create your views here.09
from .models import Scholarship

def scholarship_list(request):
    scholarships = Scholarship.objects.all()
    return render(request, 'students/available_scholarships.html', {
        'scholarships': scholarships
    })