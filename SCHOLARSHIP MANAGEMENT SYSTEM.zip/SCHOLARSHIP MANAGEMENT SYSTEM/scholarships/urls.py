from django.urls import path
from .views import scholarship_list

urlpatterns = [
    path('scholarships/', scholarship_list, name='scholarship_list'),
]
